from setuptools import setup

setup(name='ptsa',
      version='0.1',
      description='Python toolkil for timeseries anomoly detection',
      url='https://github.com/alacrity2001/SensorCleaning/tree/master/ptsa',
      author='Yinchen Wu',
      author_email='yinchen@uchicago.edu',
      license='MIT',
      packages=['ptsa'],
      zip_safe=False)